#!/bin/bash

#Config pour Resilio
sudo usermod -aG whoami rslsync
sudo chmod g+rw /data/Resilio


echo "edit file /usr/lib/systemd/user/resilio-sync.service and change WantedBy=multi-user.target to WantedBy=default.target".

vi /usr/lib/systemd/user/resilio-sync.service
wait ${!}

sleep 20

cp -r /data/Resilio/Work/Tuyaus/configDebian/.config/resilio-sync ~/.config/ 

flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo

flatpak install flathub skype vlc jdownloader inkscape gimp avidemux blender octave audacity dropbox steam wireshark libreoffice geogebra

