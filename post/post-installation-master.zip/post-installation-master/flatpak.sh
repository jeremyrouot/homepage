#!/bin/bash

flatpak install flathub skype vlc jdownloader inkscape gimp avidemux blender octave audacity dropbox steam wireshark libreoffice geogebra

