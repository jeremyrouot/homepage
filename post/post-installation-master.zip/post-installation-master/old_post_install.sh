#!/bin/bash

# Copyright © 2018 Benoît Boudaud <https://miamondo.org>
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>

user=$USER

# Suppression des fichiers inutiles :
rm ~/post-installation-master.zip
rm -r ~/post-installation-master
rm ~/README.md
rm ~/2.png
rm ~/post_install_ubserv.sh

# Création d'un répertoire et déplacement de fichiers à l'intérieur de ce répertoire
mkdir -p ~/.config/post-installation
mv ~/plank.py ~/.config/post-installation
chmod +x ~/.config/post-installation/plank.py
mv ~/plank_drag_drop.py ~/.config/post-installation
mv ~/drag_drop.mkv ~/.config/post-installation

echo "Bonjour $user. L'ordinateur va débuter la post-installation \
dès que vous aurez renseigné le mot de passe du compte ROOT."

# Installation de dialog, sudo et ajout de l'utilisateur au groupe sudo :
su root -c "apt install dialog sudo dbus \
&& adduser $user sudo \
&& echo '$user   ALL=(ALL:ALL) ALL' >> /etc/sudoers"

dialog --title "Programme de post-installation" --msgbox \
"Accrochez-vous moussaillons! Le manège va partir!" 5 60

# Installation des programmes choisis par l'utilisateur.
# Ils sont classés par ordre alphabétique :
sudo apt update \
&& sudo apt install -y \
artha \
bash-completion \
calibre \
cmake \
compton \
curl \
deluge \
evince \
feh \
flatpak \
g++ \
gfortran \
git \
gnome-disk-utility \
gnome-icon-theme \
gparted alsa-utils \
guvcview \
lightdm \
lightdm-gtk-greeter \
lxappearance \
lxterminal \
man-db \
maxima \
mpv \
obconf \
obmenu \
openbox \
pavucontrol \
#plank \
proxychains \
python3 \
python-pip \
python-pil.imagetk \
python3-tk \
redshift \
rhythmbox \
shutter \
software-properties-common \
texmaker \
texlive-full \
thunderbird \
thunar \
tint2 \
tor \
vim \
vim-addon-manager \
vim-latexsuite \
vlc \
whois \
wicd \
xbacklight \
xdg-utils \
xinit \
xserver-xorg \
youtube-dl


sudo apt autoremove # Nettoyage

# Création des répertoires de configuration pour openbox, tint2 et plank :
mkdir -p ~/.config/openbox
mkdir -p ~/.config/tint2
#mkdir -p ~/.config/plank/dock1/launchers
touch ~/.config/tint2/tint2rc # Création du fichier tint2rc

# Création de l'icône applications dans le dock plank :
#{ 
#echo "[PlankDockItemPreferences]"
#echo "Launcher=file:///usr/share/applications" 
#} > ~/.config/plank/dock1/launchers/applications.dockitem
  
# Configuration de plank
#gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ position bottom
#gsettings set net.launchpad.plank.dock.settings:/net/launchpad/plank/docks/dock1/ theme Transparent

# Configuration de tint2 :
sudo sed -i "s/left center horizontal/top center horizontal/g" /etc/xdg/tint2/tint2rc
cat /etc/xdg/tint2/tint2rc > ~/.config/tint2/tint2rc

# Création d'un sous-répertoire wallpapers pour y stocker le fond d'écran :
#mkdir -p ~/Images/Wallpapers
#mv ~/fedora_wallpaper.jpg ~/Images/Wallpapers

# Choix des programmes lancés au démarrage d'Openbox :
{
#echo "plank &"
echo "compton &"
echo "feh --bg-scale /data/Resilio/Pictures/black.png &" 
echo "tint2 &"
echo "redshift &"
echo "~/.config/post-installation/plank.py &"
} > ~/.config/openbox/autostart # Écriture dans le fichier texte   


#Resilio
echo "deb http://linux-packages.resilio.com/resilio-sync/deb resilio-sync non-free" | sudo tee /etc/apt/sources.list.d/resilio-sync.list
curl -LO http://linux-packages.resilio.com/resilio-sync/key.asc && sudo apt-key add ./key.asc


#Google
wget -q -O - https://dl.google.com/linux/linux_signing_key.pub | sudo apt-key add -
sudo apt update

sudo apt install -y google-chrome-stable resilio-sync

#Config pour Resilio
sudo usermod -aG whoami rslsync
sudo chmod g+rw /data/Resilio

cp -r /data/Resilio/Work/Tuyaus/configDebian/.config/resilio-sync ~/.config/ 
cp -r /data/Resilio/Work/Tuyaus/configDebian/.config/autostart ~/.config/ 
cp -r /data/Resilio/Work/Tuyaus/configDebian/.thunderbird ~
cp -r /data/Resilio/Work/Tuyaus/configDebian/.vnc ~
cp /data/Resilio/Work/Tuyaus/configDebian/bashrc ~/.bashrc 
source ~/.bashrc
cp /data/Resilio/Work/Tuyaus/configDebian/vimrc ~/.vimrc 
sudo cp /data/Resilio/Work/Tuyaus/configDebian/sources.list /etc/apt/

sudo apt update
sudo apt -t stretch-backports upgrade
sudo apt -t stretch-backports dist-upgrade
paquets-update

flatpak remote-add --if-not-exists flathub https://flathub.org/repo/flathub.flatpakrepo
wait ${!}

dialog --title "Programme de post-installation" --msgbox \
"Ouf! Installation terminée!" 5 40

# destruction du dernier fichier d'installation
rm ~/post_install.sh

sudo reboot

