Bonjour,

En partant d'une base Debian-Minimal, ce dépôt a pour objectif d'automatiser la post-installation d'une couche graphique avec tous les paquets nécessaires pour obtenir, au final, un système d'exploitation fonctionnel.

# Prérequis

- Créez une clé USB bootable contenant l'image iso de [**debian-9.5.0-amd64-netinst.iso**](https://www.debian.org/CD/netinst/)
- Assurez vous de disposer d'une connexion internet filaire.
- Installez Debian-Minimal sur votre ordinateur. Durant l'installation, vous allez vous retrouver devant cet écran :

    ![2.png](2.png)

- S'il y a des astérisques entre les crochets, supprimez ces derniers en utilisant la touche "espace".
- Lorsque l'installation sera terminée, vous allez vous retrouver devant une simple console tty qui va vous demander votre identifiant et votre mot de passe. Obéissez
- Ensuite, prière d'entrer cette commande qui permet de mettre à jour les paquets et de compresser/décompresser un dossier :  
    **`su -l root -c "apt update && apt install zip"`**
- Renseignez le mot de passe du compte root.
- Contrairement à **su** sans argument, cette commande ne vous laisse pas en **« root »**. Lorsqu’elle est exécutée, vous redevenez utilisateur. C’est très important! 

- Entrez cette commande qui va télécharger un dossier compressé de mon dépôt git:  
    **`wget --no-check-certificate https://framagit.org/Ordinosor/post-installation/-/archive/master/post-installation-master.zip`**
- Décompressez le dossier et déplacez les fichiers dans votre répertoire courant grâce à cette commande double :  
    **`unzip *.zip && mv post-installation-master/* ~`**
- Prenez garde de ne pas omettre les astérisques et le tilde! Le second astérisque copie le contenu du dossier **post-installation-master** dans votre répertoire utilisateur représenté ici par le tilde (**~**).

# Post-installation

- Entrez dans votre console, la double commande ci-après : **`chmod +x ./post_install.sh && ./post_install.sh`**
- Elle confère les droits d’exécution au fichier **`post_install.sh`**, avant de lancer ce dernier.
- Le script est lancé. La procédure de post-installation démarre... Il ne vous reste plus qu'à patienter avec un café ou un thé.