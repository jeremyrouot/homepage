#!/usr/bin/env python3
# -*- coding: utf8 -*-

from tkinter import *
from threading import Thread
import os
import time

def applications():
    window.destroy()
    thread_1.start()
    time.sleep(2)
    thread_2.start()
    time.sleep(2)
    thread_3.start()
    thread_1.join()
    thread_2.join()
    thread_3.join()
    
window = Tk()
window.title("Rajouter des icônes au dock")
window.resizable(width='false', height='false')

main_frame = Frame(window, bg='white')
main_frame.grid()

canvas_1 = Canvas(main_frame, bg='white', highlightthickness=0)
canvas_1.grid()
w = canvas_1.winfo_reqwidth()*1.482

label = Label(canvas_1, anchor='center', bg='white', font=('Courier', 16, 'bold'), text="Voulez-vous rajouter des icônes au dock?")
label.grid(padx=20, pady=20)

canvas_2 = Canvas(main_frame, bg='white', highlightthickness=0)
canvas_2.grid(pady=10)
h = canvas_2.winfo_reqheight()*0.7

ws = window.winfo_screenwidth()
hs = window.winfo_screenheight()
#calcul la position de la fenetre
x = (ws/2) - (w/2)
y = (hs/2) - (h/2)
#applique la taille et la position
window.geometry('%dx%d+%d+%d' % (w, h, x, y))

oui = Button(canvas_2, anchor='center', height=2, width=10, bg="black", fg="white", bd=1, font=('Courier', 16, 'bold'), relief='ridge',text='Oui', command=applications)
oui.grid(row=0, column=0, padx=20, pady=20)

non = Button(canvas_2, anchor='center', height=2, width=10, bg="black", fg="white", bd=1, font=('Courier', 16, 'bold'), relief='ridge', text='Non', command=quit)
non.grid(row=0, column=1, padx=20, pady=20)

class Actions(Thread):
    def __init__(self, command):
        Thread.__init__(self)
        self.command = command
    def run(self):
        os.system(self.command)
        
thread_1 = Actions('Thunar /usr/share/applications')
thread_2 = Actions('vlc /home/$USER/.config/post-installation/drag_drop.mkv')
thread_3 = Actions('chmod +x /home/$USER/.config/post-installation/plank_drag_drop.py && /home/$USER/.config/post-installation/plank_drag_drop.py')


window.mainloop()
