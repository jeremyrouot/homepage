#!/usr/bin/env python3
# -*- coding: utf8 -*-

from tkinter import *
from threading import Thread
import os
import time

def erase():
    if var.get()==1 :
        os.system("sed -i 's|~/.config/post-installation/plank.py &| |g' ~/.config/openbox/autostart")
        quit()
    else :
        quit()

window = Tk()
window.title("Glisser et déposer des icônes")
window.resizable(width='false', height='false')

main_frame = Frame(window, bg='white')
main_frame.grid()

canvas_1 = Canvas(main_frame, bg='white', highlightthickness=0)
canvas_1.grid()
w = canvas_1.winfo_reqwidth()*1.45

label = Label(canvas_1, bg='white', justify='left', font=('Courier', 16, 'bold'), text='Cliquez sur l\'icône de l\'application \nque vous souhaitez rajouter et, tout \nen pressant le bouton gauche de votre \nsouris, déplacez l\'icône jusqu\'au dock.')
label.grid(padx=20, pady=20)

canvas_2 = Canvas(main_frame, bg='white', highlightthickness=0)
canvas_2.grid(pady=10)
h = canvas_2.winfo_reqheight()*1.2

ws = window.winfo_screenwidth()
hs = window.winfo_screenheight()
#calcul la position de la fenetre
x = (ws/2) - (w/2)
y = (hs/2) - (h/2)
#applique la taille et la position
window.geometry('%dx%d+%d+%d' % (w, h, x, y))

OK = Button(canvas_2, anchor='center', height=2, width=10, bg="black", fg="white", bd=1, font=('Courier', 16, 'bold'), relief='ridge', text='OK', command=erase)
OK.grid(row=0, padx=20, pady=20)

var = IntVar()
checkbutton = Checkbutton(canvas_2, bg = 'white', bd=2, font=('Courier', 12, 'bold'), variable=var, text='Ne plus afficher ce message au prochain démarrage')
checkbutton.grid(row=1, padx=10, pady=10)

window.mainloop()

